<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function register_user($input_data)
	{
		$this->load->library("form_validation");
			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|is_unique[users.email]');
			$this->form_validation->set_rules('register_password', 'Password', 'required|matches[confirm_pass]|min_length[8]');
			$this->form_validation->set_rules('confirm_pass', 'Confirm Password', 'required');
			$this->form_validation->set_rules('bday','Date of Birth','required|callback_checkDateFormat'); 
			$validate = $this->form_validation->run();
		
		if ($validate == TRUE)
		{
			$user_data = array(
				'name' => $this->input->post('name'),
				'alias' => $this->input->post('alias'),
				'email' => $this->input->post('email'),
				'password' => md5($this->input->post('register_password')),
				'bday' => $this->input->post('bday')
			); 
		
			$user_query = "INSERT INTO users (name, alias, email, password, bday, created_at) 
						   VALUES (?,?,?,?,?,NOW())";
			$insert = $this->db->query($user_query, $user_data);
			$this->db->insert_id($insert);		
			$user_data['success'] = TRUE;
			$user_data['success_message'] = "You have Successfully Registered!";
		}
			else 
		{
			$user_data['success'] = FALSE;
			$user_data['register_messages'] = validation_errors();
		}
		return $user_data;	
	}


	public function add_quotes($data)
	{
		$id = $data['id'];
		$person = $data['person'];
		$quote = $data['quote'];
		
		$quote_data = array(
				'person' => $person,
				'quote' => $quote,
				'users_id' => $id,
				'favored' => 0,
				'created_at' =>  date("Y-m-d, H:i:s")
			); 
		
		$user_query = "INSERT INTO quotes (person, quote, users_id, favored, created_at) 
					   VALUES (?,?,?,?,NOW())";
	
		$insert = $this->db->query($user_query, $quote_data);
	
		return $this->db->insert_id($insert);	
	}

	public function get_user($email)
	{
		$query = $this->db->query("SELECT * FROM users WHERE email = ?", array($email))->row_array();

		return $query;
	}

	public function get_message_id()
	{
		//$favored = $this->db->query("SELECT * FROM quotes");
		$query = $this->db->query("SELECT * FROM quotes WHERE favored = ?", 0)->result_array();
		var_dump($query);
	}

	public function get_quotes($id)
	{	
		return	$this->db->query("SELECT id, person, quote, created_at, favored 
								  FROM quotes 
								  WHERE users_id = ?", array($id))->result_array();
	}

	public function get_quote($message_id)
	{	
		return $this->db->query("SELECT * FROM quotes WHERE id = ?", array($message_id))->row_array();
	}

	public function add_favorites($message_id)
	{
		// $id = $this->session->userdata('id');
		// var_dump($message_id);
		// $quote_data = array(
		// 		'quotes_id' => $message_id,
		// 		'created_at' =>  date("Y-m-d, H:i:s")
		// 	); 


		// $user_query = "UPDATE users SET quotes_id = $message_id, updated_at = NOW() WHERE id = $id";
		
		// $insert = $this->db->query($user_query, $quote_data);
		// $this->db->insert_id($insert);


		// $person = $this->db->query("SELECT alias FROM users WHERE quotes_id = ?", $message_id)->row();
	 //    $person = $person->alias;
		// $quote = $this->db->query("SELECT quote FROM quotes WHERE id = ?", $message_id)->row();
		// $quote = $quote->quote;


		// $quote_data = array(
		// 			'person' => $person,
		// 			'quote' => $quote,
		// 		'users_id' => $id,
		// 		'quotes_id' => $message_id,
		// 		'created_at' =>  date("Y-m-d, H:i:s")
		// 	); 
		
		// $user_query = "INSERT INTO favorites (person, quote, users_id, quotes_id, created_at) 
		// 			   VALUES (?,?,?,?,NOW())";
		// $insert = $this->db->query($user_query, $quote_data);
		// $this->db->insert_id($insert);	

		// return	$this->db->query("SELECT person, quote, created_at FROM favorites WHERE users_id = ?", $id)->result_array();
	}
}


